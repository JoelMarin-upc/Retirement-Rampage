GitHub page:
https://github.com/JoelMarin-upc/Retirement-Rampage

Youtube Video Link:
https://youtu.be/_L3kMHXwaUo

Team members:
Joel Marin (JoelMarin-upc)
Oscar Jimenez (OscarJimenezB)
Luying Bao (Luigi-box)

Worms: Turn based multiplayer artillery game about throwing projectiles at your opponent until their health bar depletes.

Main Title Controls:
ESC: exit game.
Enter: Start game.
left/right arrow: Change map terrain.
up/down arrow: Change map theme and background.

Controls:
Enter: Begin/End turn.
Space: Keep it pressed to charge your shot, release to shoot.
P key: pause game and bring pause menu.
ESC: exit game.

right click: pulls down the weapon selection menu, left click the weapon you want to equip.
number key 1: Change weapon to rocket, shoots in a parabola.
number key 2: Change weapon to gun, shoots in a straight line.
number key 3: Change weapon to teleport, select a location with the mouse and teleport to it with the space bar.
number key 4: Change weapon to drill, shoots in a parabola under the ground. It isn't affected by the wind.
up/down arrow: aim the shot.
left/right arrow: change aim direction.

Features:
- 3 weapons, an explosive projectile thrown in an arched motion. Exploding in a circle when hitting the ground and destroying the terrain hit by the blast.
And a bullet that goes straight but doesn't destroy terrain.
- Wind that alters the trajectory of projectiles in its direction.
- Map and theme selection.
- A teleport tool that allows you to teleport around the map.
- Destructible terrain: Terrain can be destroyed by explosives.
- Gravity: Worms will fall when no terrain is below them.
- Health: each worms have their own health, each hit will substrat from it.
- Timer: whenever a turn begins a timer starts. When it runs out it will switch turns to the other player.
- Animations: All characters and weapons have their own unique animations.
- Sound effects: Sound effects play when using any weapon.
- Soundtrack: A background track plays when starting the game and loops until closed.
- Win/Lose state: when a player reaches 0 health or falls off the map they lose and a game over screen appears.
